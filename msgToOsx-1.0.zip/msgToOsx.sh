#!/bin/bash
########################################################################
# Author: Inaki Rodriguez
#
# Description: Basically run basic tasks using AWS CLI
#              This script can be optimized somehow for
#              custom scripts
#
########################################################################

java -jar ./msgToOsx-1.0.jar $1