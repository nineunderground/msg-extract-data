#########################
#			#
#	HOW TO USE	#
#			#
#########################

1. Just add execution permissions to the jar file:
chmod u+x msgToOsx.sh

2. Run with a valid *msg file:
./msgToOsx.sh <YOUR_FILE.MSG>
